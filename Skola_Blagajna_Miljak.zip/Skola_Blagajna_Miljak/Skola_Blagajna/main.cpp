#include <iostream>

using namespace std;

double CIJENA_ULAZNICE = 5.0;
int PRAG_POPUSTA = 5;
double STOPA_POPUSTA = 0.10;

int ukupnoUlaznica = 0;
double ukupniPrihod = 0.0;

bool ispravanUnos(int kolicina);
double izracunajIznos(int kolicina);
void evidentirajKupnju(int kolicina, double iznos);
void ispisiKupnju(int redniBroj, double iznos);
void ispisiSazetak();

int main() {
    for (int i = 1; i <= 3; i++) {
        int kolicina = 0;

        while (ispravanUnos(kolicina) == false) {
            cout << "Kupnja " << i << " - unesi broj ulaznica (1-30): ";
            cin >> kolicina;
        }

        double iznos = izracunajIznos(kolicina);
        evidentirajKupnju(kolicina, iznos);
        ispisiKupnju(i, iznos);
    }

    ispisiSazetak();

    return 0;
}


bool ispravanUnos(int kolicina) {
    return kolicina >= 1 && kolicina <= 30;
}

double izracunajIznos(int kolicina) {
    double osnovniIznos = kolicina * CIJENA_ULAZNICE;
    double konacniIznos = osnovniIznos;

    if (kolicina >= PRAG_POPUSTA) {
        konacniIznos = osnovniIznos * (1.0 - STOPA_POPUSTA);
    }

    return konacniIznos;
}

void evidentirajKupnju(int kolicina, double iznos) {
    ukupnoUlaznica = ukupnoUlaznica + kolicina;
    ukupniPrihod = ukupniPrihod + iznos;
}

void ispisiKupnju(int redniBroj, double iznos) {
    cout << "Kupnja " << redniBroj << ": " << iznos << " EUR" << endl;
}

void ispisiSazetak() {
    cout << "Ukupno prodanih ulaznica: " << ukupnoUlaznica << endl;
    cout << "Ukupni prihod: " << ukupniPrihod << " EUR" << endl;
}
