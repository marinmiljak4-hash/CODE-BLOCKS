#include <iostream>

using namespace std;
void Paran(int a){
    if(a%2==0){
        printf("Paran je broj\n");
    }
    else{
        printf("Neparan je broj\n");
    }
}
void Apsolutna(int a){
    cout<<"apsolutna vrijednost broja je: "<<abs(a)<<endl;
}
void Kvadrat(int a){
    cout<<"Kvadrat broja je: "<<a*a<<endl;
}

int main()
{
    int a;
    printf("Upisi cijeli broj; ",a);
    scanf("%i",&a);

    Paran(a);
    Apsolutna(a);
    Kvadrat(a);
    return 0;
}
