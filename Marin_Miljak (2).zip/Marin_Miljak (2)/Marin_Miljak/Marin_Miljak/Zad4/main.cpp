#include <iostream>

using namespace std;

int main()
{
    int a,b;
    cout<<"Unesi ostvarene bodove: "<<endl;
    cin>>a;
    cout<<("Unesi maksimalan broj bodova: ")<<endl;
    cin>>b;

    printf("")

    return 0;
}
