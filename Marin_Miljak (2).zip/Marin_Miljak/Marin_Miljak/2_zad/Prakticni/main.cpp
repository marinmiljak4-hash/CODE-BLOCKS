#include <iostream>

using namespace std;

double prosjek(int a,int b){
    double rezultat=(a+b) / 2.0;
    return rezultat;
}
int main()
{
    int a=0;
    int b=0;

    std::cin >> a >> b;
    std::cout << prosjek(a,b);
    return 0;
}
